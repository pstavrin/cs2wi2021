package edu.caltech.cs2.project01;


public class Solver {
    public static void main(String[] args) {


    }



}
